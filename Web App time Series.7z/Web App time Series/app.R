# This Web App aims Explain some of the important aspects of time Series. 
# this Web app is made as a part of a study project  in M.Sc Hydro Science and Engineering
# created by : Amjad Ahmed , Alfonso Recalde , Arun Somasundaram group 15a last update:08/07/2019
# please Install the following libraries , use function install.packages("package name")

library(shiny)
library(shinythemes)
library(shinydashboard)
library(ggplot2)
library(packrat)
library(tseries)
library(Kendall)

ui <-shinyUI(fluidPage(theme = shinytheme("flatly"),
      #app Title 
 titlePanel(tags$a(href='https://en.wikipedia.org/wiki/Time_series ', 'Time Sereis')),
      # the main panel is divided into three tabs: Explaination , Plots and Tests
      # the Sidebarpanel is accessable on the plots and the Tests tab only.
    tabsetPanel(
            
      #Explaination tab                       
      tabPanel(h4(strong( "Explaination")),icon = icon("fas fa-book"),
          mainPanel(
            tags$img(src ="What is a time series3.jpg", width = "1800px" , height = "1416px")
            
          )),
                         
       # Graphic tab                     
   tabPanel (h4(strong("  Plots ")),icon = icon("fas fa-chart-line"),
        sidebarPanel(width = 3,
           sliderInput("time","Enter the Number of time steps :", min = 0 , max = 1000 , value = 100),
           sliderInput("tim", "Enter the lag :", min = 20 , max = 500 , value = 50),paste("*The lag should not be more than the number of steps"),
           radioButtons("type", label = "Select Process Type :", choices = list("Trend Staionary Process" = "trend","Difference Stationary Process" = "diff")),
           
           # for TSP
        conditionalPanel(condition = "input.type == 'trend'", 
           numericInput("intersect",label ="Enter the intersect of the trend line",value = 0.2,step = .1 ),
           numericInput("slope",label ="Enter the Slope of the trend line",value = 0.5,step = .1 )),
           
           # for DSP
        conditionalPanel(condition = "input.type == 'diff'",
           numericInput("cons",label ="Enter the shift between two consecutive points",value = 0.5 ,step =.1 )),
           
           numericInput("errorm",label ="Enter the time series error mean",value = 0 ,step = .1 ),
           numericInput("errorsd",label ="Enter the error standard diviation",value = 1 ,step = .1 ),
          
          actionButton("reset", "Refresh")
          
                               ),
        mainPanel(width= 8,
                
                  splitLayout(style = "border: 1px solid silver:", cellWidths = 450,cellHeights = 400,cellArgs = list(style = "padding: 6px"),
                         plotOutput("plot"), plotOutput("plottr"), plotOutput("plotd")),
                  splitLayout(style = "border: 1px solid silver:", cellWidths = 450,cellHeights = 400,cellArgs = list(style = "padding: 6px"),
                         plotOutput("ACF"),plotOutput("ACFtr"),plotOutput("ACFd")))),
      
         # Tests Tab
   tabPanel(h4(strong("  Tests  ")), icon = icon("fas fa-edit"),
        sidebarPanel(width = 3,
        sliderInput("timet","Enter the Number of time steps :", min = 0 , max = 1000 , value = 100),
        sliderInput("timt", "Enter the lag :", min = 20 , max = 500 , value = 50),paste("*The lag should not be more than the number of steps"),
        radioButtons("typet", label = "Select Process Type :", choices = list("Trend Staionary Process" = "trendt","Difference Stationary Process" = "difft")),
                        
         # for TSP
            conditionalPanel(condition = "input.typet == 'trendt'", 
               numericInput("intersectt",label ="Enter the intersect of the trend line",value = 0.2,step = .1 ),
               numericInput("slopet",label ="Enter the Slope of the trend line",value = 0.5,step = .1 )),
         # for DSP
            conditionalPanel(condition = "input.typet == 'difft'",
              numericInput("const",label ="Enter the shift between two consecutive points",value = 0.5 ,step =.1 )),
                         
              numericInput("errormt",label ="Enter the time series error mean",value = 0 ,step = .1 ),
              numericInput("errorsdt",label ="Enter the error standard diviation",value = 1 ,step = .1 ),
        
                         actionButton("resett", "Refresh")
                         
            ),
       mainPanel(
                splitLayout(style = "padding: 6px", cellWidths = 900,cellHeights = 700,cellArgs = list(style = "padding: 6px"),verbatimTextOutput("texta")),
                splitLayout(style = "padding: 6px", cellWidths = 900,cellHeights = 700,cellArgs = list(style = "padding: 6px"),verbatimTextOutput("textb")),
                splitLayout(style = "padding: 6px", cellWidths = 900,cellHeights = 700,cellArgs = list(style = "padding: 6px"),verbatimTextOutput("textc")))
              ) 
              )))
#______________________________________________________________________________________________________________________________________________________________


server <- function(input,output){
  
  # for the Time series plot
  # for TSP
  #set the time series as reactive variables to get consistent random numbers for the different plot outputs
  
  tspr <- reactive({
    #for the refresh button to work
    reset <- input$reset
    # for the TS
    time1 <- 1:input$time
    TSP <- input$intersect + (input$slope * time1) + rnorm(time1, mean= input$errorm, sd = abs(input$errorsd))
    TSP
  })
  # for the tests tab
  tsprt <- reactive({
    #for the refresh button to work
    reset <- input$resett
    # for the TS
    time1 <- 1:input$timet
    TSP <- input$intersectt + (input$slopet * time1) + rnorm(time1, mean= input$errormt, sd = abs(input$errorsdt))
    TSP
  })
  dspr <- reactive({
    reset <- input$reset
    time1 <- 1:input$time
    DSP <- numeric(length(time1))
    DSP[1] <- rnorm(1 , mean = input$errorm , sd = abs(input$errorsd))
    for (tt in time1[-1])
      DSP[tt] <- DSP[tt-1] + input$cons + rnorm(1, mean = input$errorm , sd = abs(input$errorsd))
    DSP
  })
  # for the the tests tab
  dsprt <- reactive({
    reset <- input$resett
    time1 <- 1:input$timet
    DSP <- numeric(length(time1))
    DSP[1] <- rnorm(1 , mean = input$errormt , sd = abs(input$errorsdt))
    for (tt in time1[-1])
      DSP[tt] <- DSP[tt-1] + input$const + rnorm(1, mean = input$errormt , sd = abs(input$errorsdt))
    DSP
  })
  
  
  output$plot <- renderPlot({
    type1<-input$type
    effect <- input$effect
    # for TSP
    if(type1 =="trend"  )
    {
      TSP <- tspr()
      TSP<-ts(TSP)
      plot(TSP , main = "Trend Stationary Process")
      
    }
    
    #for DSP
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP)  
      plot(DSP , main = "Difference Stationary Process")
    }})
  
  # the same block is repeated for different outputs
  # for the Auto Correlation function
  
  output$ACF <- renderPlot({
    type1<-input$type
    
    if(type1 =="trend"){
      TSP <- tspr()
      TSP<-ts(TSP)
      acf(TSP , main = "Auto Correlation Function", lag.max =input$tim)
      
    }
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP)  
      acf(DSP, main = "Auto Correlation Function" , lag.max =input$tim)
      
      
    }})
  
  # Plot for trend removal 
  output$plottr <- renderPlot({
    type1<-input$type
    
    if(type1 =="trend"){
      
      TSP <- tspr()
      TSP<-ts(TSP)
      TSPx <- ts(residuals(lm(TSP ~ time(TSP))))
      plot(TSPx, main = "Removed Trend", ylab = "Level Stationary Process")
      
    }
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP) 
      DSPx <- ts(residuals(lm(DSP ~ time(DSP))))
      plot(DSPx, main = "Removed Trend" , ylab ="")
      
    }})
  
  output$ACFtr <- renderPlot({
    type1<-input$type
    if(type1 =="trend"){
      TSP <- tspr()
      TSP<-ts(TSP)
      TSPx <- ts(residuals(lm(TSP ~ time(TSP))))
      acf(TSPx, main = "Removed Trend", lag.max =input$tim )
      
      
    }
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP) 
      DSPx <- ts(residuals(lm(DSP ~ time(DSP))))
      acf(DSPx, main = "Removed Trend", lag.max =input$tim )
      
      
    }})
  output$plotd <- renderPlot({
    type1<-input$type
    
    if(type1 =="trend"){
      
      TSP <- tspr()
      TSP<-ts(TSP)
      TSPy <- diff(TSP)
      plot(TSPy, main = "Differencing of Trend Sationary Process", ylab ="")
      
    }
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP) 
      DSPy <- diff(DSP)
      plot(DSPy, main = "Differencing of Difference stationary Process", ylab = "Level Stationary Process") # check the title of this graph
    }})
  
  output$ACFd <- renderPlot({
    type1<-input$type
    if(type1 =="trend"){
      TSP <- tspr()
      TSP<-ts(TSP)
      TSPy <- diff(TSP)
      acf(TSPy, main = "Differencing of Trend Sationary Process", lag.max =input$tim )
      
    }
    else if(type1 =="diff"){
      DSP <- dspr()
      DSP<-ts(DSP) 
      DSPy <- diff(DSP)
      acf(DSPy, main = "Level Sationary Process", lag.max =input$tim ) #check title here also
      
    }})
  
  #Augumented Dicky-Fuller Test
  output$texta <- renderPrint({
    type1 <- input$typet
    if(type1 =="trendt"){
      TSP <- tsprt()
      TSP <-ts(TSP)
      adf <- adf.test(TSP)
      adf
      
    }
    else if(type1 =="difft"){
      DSP <- dsprt()
      DSP<-ts(DSP)  
      adf <- adf.test(DSP)
      adf
    }})
  #KPSS test
  output$textb <- renderPrint({
    type1<-input$typet
    
    if(type1 =="trendt"){
      TSP <- tsprt()
      TSP<- ts(TSP)
      kpss  <- kpss.test(TSP)
    kpss
    }
    else if(type1 =="difft"){
      DSP <- dsprt()
      DSP<- ts(DSP)  
      kpss <- kpss.test(DSP)
      kpss
    }})
  # Mannkendel Test
  output$textc <- renderPrint({
    type1<-input$typet
    
    if(type1 =="trendt"){
      TSP <- tsprt()
      TSP<-ts(TSP)
      Mann <- MannKendall(TSP)
      Mann
    }
    else if(type1 == "difft"){
      cat(" The test is not Suitable Because Residuals are correlated")
      
    }})
}
shinyApp(ui,server)